document.addEventListener("DOMContentLoaded", () => {
  const slides = document.querySelectorAll(".hero-slide");
  let index = 0;

  function showSlide(i) {
    slides.forEach(s => s.classList.remove("active"));
    slides[i].classList.add("active");
  }

  window.nextHero = () => {
    index = (index + 1) % slides.length;
    showSlide(index);
  };

  window.prevHero = () => {
    index = (index - 1 + slides.length) % slides.length;
    showSlide(index);
  };

  setInterval(nextHero, 6000);
});
