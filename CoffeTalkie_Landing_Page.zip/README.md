---
title: CoffeeComrade
emoji: 💻
colorFrom: gray
colorTo: blue
sdk: static
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
