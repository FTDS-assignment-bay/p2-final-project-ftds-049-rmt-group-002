import streamlit as st
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from typing import Dict, Any, List
import json
from pathlib import Path

from dataclasses import dataclass


@dataclass
class UserPref:
    stomach_sensitivity: str
    caffeine_sensitivity: str
    time_of_day: str
    purpose: str
    flavor_direction: List[str]
    brew_method: str

# BASE PATH
BASE_DIR = Path(__file__).resolve().parent
ARTIFACT_PATH = BASE_DIR / "artifacts"

# LOAD
@st.cache_resource
def load_artifacts():
    vectorizer_path = ARTIFACT_PATH / "tfidf_vectorizer.joblib"
    matrix_path = ARTIFACT_PATH / "products_tfidf_matrix.joblib"
    df_path = ARTIFACT_PATH / "products_fe.csv"
    config_path = ARTIFACT_PATH / "ranking_config.json"
    
    # Check File ada atau tidak
    for p in [vectorizer_path, matrix_path, df_path, config_path]:
        if not p.exists():
            raise FileNotFoundError(f"Artifact not found: {p}")

    return {
        "vectorizer": joblib.load(vectorizer_path),
        "df": pd.read_csv(df_path),
        "X": joblib.load(matrix_path),
        "ranking_config": json.load(open(config_path, encoding="utf-8")),
    }


# Coffe Profile
def build_coffee_profile(pref: UserPref) -> Dict[str, Any]:
    profile = {}

    # Acid
    if pref.stomach_sensitivity == "high":
        profile["acidity_level"] = "low"
        profile["roast_level"] = "dark"
    elif pref.stomach_sensitivity == "medium":
        profile["acidity_level"] = "medium"
        profile["roast_level"] = "medium"
    else:
        profile["acidity_level"] = "high"
        profile["roast_level"] = "light"

    # CCaffein
    if pref.caffeine_sensitivity == "high":
        profile["bean_pref"] = "arabica"
    else:
        profile["bean_pref"] = "robusta"

    # Time
    if pref.time_of_day == "evening":
        profile["roast_level"] = "dark"

    # Porpose
    if pref.purpose == "focus":
        profile["process_preference"] = "washed"
    elif pref.purpose == "calm":
        profile["process_preference"] = "honey"
    else:
        profile["process_preference"] = "natural"

    # Brew
    if pref.brew_method == "espresso":
        profile["roast_level"] = "medium_dark"
    elif pref.brew_method == "filter":
        profile["roast_level"] = "light"

    # Flavour
    profile["flavor_direction"] = pref.flavor_direction

    return profile


# Query
def build_query_text(profile: Dict[str, Any]) -> str:
    tokens = [
        f"roast_{profile['roast_level']}",
        f"process_{profile['process_preference']}",
        f"bean_{profile['bean_pref']}",
    ]

    for f in profile.get("flavor_direction", []):
        tokens.append(f"notes_{f}")

    if profile["acidity_level"] == "high":
        tokens.extend(["notes_fruity", "notes_floral"])

    return " ".join(dict.fromkeys(tokens))


# Rerank
def rerank_candidates(df, profile, config):
    df = df.copy()
    df["final_score"] = df["similarity"]

    boo = config.get("boost", {})
    if profile.get("roast_level"):
        df.loc[df["roast"] == profile["roast_level"],
               "final_score"] += boo.get("roast_match", 0)

    if profile.get("process_preference"):
        df.loc[df["process"] == profile["process_preference"],
               "final_score"] += boo.get("process_match", 0)

    return df.sort_values("final_score", ascending=False)


# Define UI untuk Result
def render_product_card(row, rank):
    st.markdown("---")
    st.subheader(f"#{rank}. {row['name']}")
    st.caption(f"Source: {row['source']}")
    st.markdown(
        f"""
        **Price:** Rp {row['price']:,}  
        **Score:** `{row['final_score']:.3f}`
        """
    )

# Reset RECOMENDATION
if "show_result" not in st.session_state:
    st.session_state.show_result = False

if "final_results" not in st.session_state:
    st.session_state.final_results = None

if "debug_info" not in st.session_state:
    st.session_state.debug_info = None
    
def run_predict():

    artifacts = load_artifacts()
    vectorizer = artifacts["vectorizer"]
    df_fe = artifacts["df"]
    X_tfidf = artifacts["X"]
    ranking_config = artifacts["ranking_config"]

    st.title("Coffee Recommendation System")
    st.caption("User Preference → Coffee Profile → Product Matching")

    # Form
    with st.form("user_pref_form"):
        st.subheader("Tell Us About You")

        col1, col2 = st.columns(2)

        with col1:
            stomach_sensitivity = st.selectbox(
                "How sensitive is your stomach to coffee?",
                ["LOW", "MEDIUM", "HIGH"]
            )
            st.caption(
                "Some people feel uncomfortable after having coffee. "
                "Tell us how sensitive you are."
            )

            caffeine_sensitivity = st.selectbox(
                "How strong can you handle caffeine?",
                ["LOW", "MEDIUM", "HIGH"]
            )

            time_of_day = st.selectbox(
                "When do you usually drink coffee?",
                ["MORNING", "AFTERNOON", "EVENING"]
            )

        with col2:
            purpose = st.selectbox(
                "What do you want from coffee right now?",
                ["FOCUS", "BALANCED", "CALM"]
            )

            flavor_direction = st.multiselect(
                " What flavors do you enjoy? (Choose up to 2)",
                ["FRUITY", "SWEET", "CHOCOLATE_NUTTY", "FLORAL", "SPICY"],
                max_selections=2
            )

            brew_method = st.selectbox(
                "How do you usually make your coffee?",
                ["FILTER", "ESPRESSO", "BOTH"]
            )

        btn_col1, btn_col2 = st.columns([2, 1])

        with btn_col1:
            submit_recommend = st.form_submit_button("Recommend Coffee")

        with btn_col2:
            submit_reset = st.form_submit_button("Reset Recommend Coffee")

    # Submit Method
    if submit_recommend:
        if len(flavor_direction) == 0:
            st.error("PLEASE SELECT AT LEAST ONE FLAVOR YOU ENJOY!!!")
            st.stop()
            
        user_pref = UserPref(
            stomach_sensitivity=stomach_sensitivity.lower(),
            caffeine_sensitivity=caffeine_sensitivity.lower(),
            time_of_day=time_of_day.lower(),
            purpose=purpose.lower(),
            flavor_direction=[f.lower() for f in flavor_direction],
            brew_method=brew_method.lower(),
        )


        coffee_profile = build_coffee_profile(user_pref)
        query_text = build_query_text(coffee_profile)

        q_vec = vectorizer.transform([query_text])
        similarity = cosine_similarity(q_vec, X_tfidf).ravel()

        top_idx = np.argsort(similarity)[::-1][:20]
        candidates = df_fe.iloc[top_idx].copy()
        candidates["similarity"] = similarity[top_idx]

        final_results = rerank_candidates(
            candidates, coffee_profile, ranking_config
        ).head(10)

        st.session_state.final_results = final_results
        st.session_state.debug_info = {
            "user_pref": user_pref.__dict__,
            "coffee_profile": coffee_profile,
            "query_text": query_text,
        }
        st.session_state.show_result = True

        if st.session_state.show_result and st.session_state.final_results is not None:
            st.subheader("Recommended Coffees")

            for i, (_, row) in enumerate(
                st.session_state.final_results.iterrows(), start=1
            ):
                render_product_card(row, i)

            with st.expander("Recommendation Logic"):
                st.markdown("### User Preference")
                st.json(st.session_state.debug_info["user_pref"])

                st.markdown("### Generated Coffee Profile")
                st.json(st.session_state.debug_info["coffee_profile"])

                st.markdown("### Query Text")
                st.code(st.session_state.debug_info["query_text"])

        if submit_reset:
            st.session_state.show_result = False
            st.session_state.final_results = None
            st.session_state.debug_info = None
            st.rerun()

if __name__ == "__main__":
    run_predict()
