# import streamlit as st
# import pandas as pd
# import matplotlib.pyplot as plt
# import re
# import numpy as np
# import plotly.express as px


# def run_eda():
#     # LOAD DATA 

#     @st.cache_data
#     def load_data():
#         return pd.read_csv("tokopedia_products_cleaned.csv")

#     df_Cleaned = load_data()

#     # HEADER 

#     st.title("Exploratory Data Analysis")
#     st.markdown(
#         "This section explores the coffee dataset, focusing on bean types, price distribution, and premium products."
#     )

#     st.subheader("Dataset Overview")
#     st.dataframe(df_Cleaned.head())

#     col1, col2, col3 = st.columns(3)
#     col1.metric("Total Products", len(df_Cleaned))
#     col2.metric("Coffee Products", df_Cleaned["is_coffee"].sum())
#     col3.metric("Sources", df_Cleaned["source"].nunique())
    
#     # LOAD DATA READY 
    
#     @st.cache_data
#     def load_data():
#         return pd.read_csv("tokopedia_products_ready.csv")

#     df_coffe = load_data()

#     # FILTER DATA 
#     df_arabica = df_coffe[df_coffe["description"].str.contains("arabica", case=False, na=False)]
#     df_robusta = df_coffe[df_coffe["description"].str.contains("robusta", case=False, na=False)]

#     # PIE CHART DATA 
#     st.subheader("Arabica vs Robusta Distribution")

#     labels = ['Robusta', 'Arabica']
#     values = [len(df_robusta), len(df_arabica)]

#     fig = px.pie(
#         names=labels,
#         values=values,
#         title="Coffee Type Distribution",
#         hole=0.45,
#         color_discrete_sequence=["#6F4E37", "#C7A17A"]
#     )

#     fig.update_layout(
#         width=1000,
#         height=600
#     )

#     st.plotly_chart(fig)
    
#     st.markdown("""
#     #### Key Insights
#     """)


#     # RATA - RATA HARGA 
#     st.subheader("Average Price Comparison")

#     avg_price = {
#         "Robusta": df_robusta['price'].mean(),
#         "Arabica": df_arabica['price'].mean()
#     }

#     fig = px.bar(
#         x=avg_price.keys(),
#         y=avg_price.values(),
#         title="Average Coffee Price",
#         labels={"x": "Coffee Type", "y": "Average Price"},
#         color=avg_price.keys(),
#         color_discrete_sequence=["#8B5A2B", "#C19A6B"]
#     )

#     fig.update_layout(
#         width=700,
#         height=700
#     )

#     st.plotly_chart(fig)
#     # PREPARE HARGA PER 100 G


#     def prepare_arabica_products(df_arabica):
#         df = df_arabica.copy()

#         # Remove drip bag products
#         df = df[
#             ~df.astype(str)
#             .apply(lambda row: row.str.contains('drip bag', case=False).any(), axis=1)
#         ]

#         df['quantity'] = np.nan

#         quantity_patterns = {
#             100: r'\b100\s*(g|gr|gram)(?!\s*%)\b',
#             150: r'\b150\s*(g|gr|gram)\b',
#             200: r'\b200\s*(g|gr|gram)\b',
#             400: r'\b400\s*(g|gr|gram)\b',
#             500: r'\b500\s*(g|gr|gram)\b',
#             1000: r'\b(1000\s*(g|gr|gram)|1\s*kg)\b'
#         }

#         for qty, pattern in quantity_patterns.items():
#             mask = (
#                 df['quantity'].isna() &
#                 df[['name', 'description']]
#                 .astype(str)
#                 .apply(
#                     lambda r: r.str.contains(pattern, case=False, regex=True).any(),
#                     axis=1
#                 )
#             )
#             df.loc[mask, 'quantity'] = qty

#         def extract_gram(row):
#             text = f"{row.get('name','')} {row.get('description','')}".lower()

#             if re.search(r'\b(l|liter|ml|milliliter|sachet)\b', text):
#                 return np.nan

#             match = re.search(r'\b(\d+)\s*(kg|g|gr|gram)\b', text)
#             if not match:
#                 return np.nan

#             value = int(match.group(1))
#             unit = match.group(2)

#             return value * 1000 if unit == 'kg' else value

#         mask_null = df['quantity'].isna()
#         df.loc[mask_null, 'quantity'] = df.loc[mask_null].apply(extract_gram, axis=1)

#         df = df.dropna(subset=['quantity'])

#         # df['price_gram'] = (df['price'] / df['quantity']).round(2)
#         df['price_100g'] = (df['price'] / df['quantity'] * 100).round(0)

#         return df

#     # TOP 5 ARABICA 

#     arabica_product = prepare_arabica_products(df_arabica)
#     # st.write(arabica_product.columns)

#     top5_arabica = arabica_product.sort_values(
#         'price_100g', ascending=False
#         ).head(5)
#     # TOP 5 TERMAHAL 
#     st.subheader("Top 5 Most Expensive Arabica Beans")

#     fig = px.bar(
#         top5_arabica,
#         x="price_100g",
#         y="name",
#         orientation="h",
#         title="Top 5 Most Expensive Arabica Beans (per 100g)",
#         labels={"price_100g": "Price per 100g", "name": "Product"},
#         color="price_100g",
#         color_continuous_scale="YlOrBr"
#     )

#     fig.update_layout(
#         yaxis=dict(autorange="reversed"),
#         height=500
#     )

#     st.plotly_chart(fig, use_container_width=True)

#     # TOP 5 TERMURAH 

#     st.subheader("Top 5 Cheapest Arabica Beans")
    
#     low5_arabica = (
#         arabica_product
#         .sort_values('price_100g', ascending=True)
#         .head(5)
#     )

#     fig = px.bar(
#         low5_arabica,
#         x="price_100g",
#         y="name",
#         orientation="h",
#         title="Top 5 Most Expensive Arabica Beans (per 100g)",
#         labels={"price_100g": "Price per 100g", "name": "Product"},
#         color="price_100g",
#         color_continuous_scale="YlOrBr"
#     )

#     fig.update_layout(
#         yaxis=dict(autorange="reversed"),
#         height=500
#     )

#     st.plotly_chart(fig, use_container_width=True)
    
    
    
    
#      # PREPARE HARGA PER 100 G


#     def prepare_robusta_products(df_robusta):
#         df = df_robusta.copy()

#         # Remove drip bag products
#         df = df[
#             ~df.astype(str)
#             .apply(lambda row: row.str.contains('drip bag', case=False).any(), axis=1)
#         ]

#         df['quantity'] = np.nan

#         quantity_patterns = {
#             100: r'\b100\s*(g|gr|gram)(?!\s*%)\b',
#             150: r'\b150\s*(g|gr|gram)\b',
#             200: r'\b200\s*(g|gr|gram)\b',
#             400: r'\b400\s*(g|gr|gram)\b',
#             500: r'\b500\s*(g|gr|gram)\b',
#             1000: r'\b(1000\s*(g|gr|gram)|1\s*kg)\b'
#         }

#         for qty, pattern in quantity_patterns.items():
#             mask = (
#                 df['quantity'].isna() &
#                 df[['name', 'description']]
#                 .astype(str)
#                 .apply(
#                     lambda r: r.str.contains(pattern, case=False, regex=True).any(),
#                     axis=1
#                 )
#             )
#             df.loc[mask, 'quantity'] = qty

#         def extract_gram(row):
#             text = f"{row.get('name','')} {row.get('description','')}".lower()

#             if re.search(r'\b(l|liter|ml|milliliter|sachet)\b', text):
#                 return np.nan

#             match = re.search(r'\b(\d+)\s*(kg|g|gr|gram)\b', text)
#             if not match:
#                 return np.nan

#             value = int(match.group(1))
#             unit = match.group(2)

#             return value * 1000 if unit == 'kg' else value

#         mask_null = df['quantity'].isna()
#         df.loc[mask_null, 'quantity'] = df.loc[mask_null].apply(extract_gram, axis=1)

#         df = df.dropna(subset=['quantity'])

#         # df['price_gram'] = (df['price'] / df['quantity']).round(2)
#         df['price_100g'] = (df['price'] / df['quantity'] * 100).round(0)

#         return df
    
#     robusta_product = prepare_robusta_products(df_robusta)

#     # TOP 5 ROBUSTA 

#     st.subheader("Top 5 Most Expensive Robusta Beans")

#     top5_robusta = (
#         robusta_product.sort_values("price_100g", ascending=False)
#         .head(5)
#     )
    
#     fig = px.bar(
#         top5_robusta,
#         x="price_100g",
#         y="name",
#         orientation="h",
#         title="Top 5 Most Expensive Robusta Beans (per 100g)",
#         labels={"price_100g": "Price per 100g", "name": "Product"},
#         color="price_100g",
#         color_continuous_scale="YlOrBr"
#     )

#     fig.update_layout(
#         yaxis=dict(autorange="reversed"),
#         height=500
#     )

#     st.plotly_chart(fig, use_container_width=True)
    
    
    
#     ## TOP 5 CHEAPEST ROBUSTA BEANS

#     st.subheader("Top 5 Cheapest Robusta Beans")

#     low5_robusta = (
#         robusta_product.sort_values("price_100g", ascending=True)
#         .head(5)
#     )

#     fig = px.bar(
#         low5_robusta,
#         x="price_100g",
#         y="name",
#         orientation="h",
#         title="Top 5 Most Expensive Robusta Beans (per 100g)",
#         labels={"price_100g": "Price per 100g", "name": "Product"},
#         color="price_100g",
#         color_continuous_scale="YlOrBr"
#     )

#     fig.update_layout(
#         yaxis=dict(autorange="reversed"),
#         height=500
#     )

#     fig.update_layout(width=700)

#     st.plotly_chart(fig)

# if __name__=='__main__':
#     run_eda()
