import streamlit as st
import pandas as pd
import numpy as np
import re
import plotly.express as px

from predict import run_predict

st.set_page_config(
    page_title="Coffee Dashboard",
    layout="wide"
)

HF_HOME_URL = "https://huggingface.co/spaces/MichaelFA/CoffeeComrade"

st.sidebar.markdown("## Navigation")
st.sidebar.markdown(f"[Home]({HF_HOME_URL})")

# Sidebar
menu = ["Dashboard", "Predict"]
choice = st.sidebar.selectbox("Menu", menu)


# DASHBOARD / EDA
if choice == "Dashboard":
    st.title("Coffee Dataset Dashboard")
    
    
    # LOAD DATA 
    @st.cache_data
    def load_cleaned():
        return pd.read_csv("./src/tokopedia_products_cleaned.csv")

    @st.cache_data
    def load_ready():
        return pd.read_csv("./src/tokopedia_products_ready.csv")

    df_cleaned = load_cleaned()
    df_ready = load_ready()

    # Filter coffee types
    df_arabica = df_ready[df_ready["description"].str.contains("arabica", case=False, na=False)]
    df_robusta = df_ready[df_ready["description"].str.contains("robusta", case=False, na=False)]

    st.title("Exploratory Data Analysis")
    st.markdown(
        """
        This section explores the coffee product dataset from Tokopedia,  
        focusing on **bean type distribution**, **price comparison**,  
        and **premium vs affordable products**.
        """
    )

    tabs = st.tabs(["Overview", "Quality and Coverage", "Roastery Information","Beans Information","Beans Distribution"])

    # TAB 1
    with tabs[0]:
        st.subheader("Dataset Overview")

        st.dataframe(df_cleaned.head())

        col1, col2, col3 = st.columns(3)
        col1.metric("Total Products", len(df_cleaned))
        col2.metric("Coffee Products", int(df_cleaned["is_coffee"].sum()))
        col3.metric("Sources", df_cleaned["source"].nunique())

        with st.expander("About This Dataset"):
            st.markdown(
                """
                - Dataset collected from **Tokopedia**
                - Cleaned to remove non-coffee and irrelevant products
                - Focused on **coffee beans**, excluding drinks & tools
                - Further segmented into **Arabica** and **Robusta**
                """
            )

        st.divider()
        
        # Statistic EDA 
        df_text = df_ready.copy()
        
        df_text["desc_len"] = df_text["description"].fillna("").str.len()
        df_text["name_len"] = df_text["name"].fillna("").str.len()
        
        st.subheader("Text Exploration and Statistics")

        st.markdown(
            """
            This section analyzes the **textual characteristics** of product names and descriptions,
            focusing on **length distribution, completeness, and variability**.
            """
        )
        
        total_rows = len(df_text)

        empty_desc_pct = (
            (df_text["description"].isna() | (df_text["description"].str.strip() == ""))
            .mean() * 100
        )

        SHORT_THRESHOLD = 900
        short_desc_pct = (df_text["desc_len"] < SHORT_THRESHOLD).mean() * 100

        col1, col2, col3, col4 = st.columns(4)

        col1.metric("Total Products", total_rows)
        col2.metric("Avg Description Length", int(df_text["desc_len"].mean()))
        col3.metric("Empty Descriptions (%)", f"{empty_desc_pct:.2f}%")
        col4.metric("Short Descriptions (%)", f"{short_desc_pct:.2f}%")
        
        with st.expander("Insight"):
            st.markdown(
                """
                The average text length of the description column is approximately 950 characters, 
                which is significantly longer than the name column, averaging around 70 characters. 
                This indicates that the majority of product information 
                such as coffee characteristics  and sales details is concentrated in the description field, 
                while the name field remains concise and primarily serves as a product identifier.
                """
            )
        
        st.divider()
        
        st.subheader("Description Length Distribution (Characters)")
        
        fig = px.histogram(
            df_text,
            x="desc_len",
            nbins=50,
            title="Description Length Distribution (Characters)",
            labels={"desc_len": "Number of Characters"},
            color_discrete_sequence=["#8B5A2B", "#C19A6B"]
        )

        fig.update_layout(
            height=700,
            bargap=0.05
        )

        st.plotly_chart(fig, use_container_width=True)

        with st.expander("Insight"):
            st.markdown(
                """
                Most product descriptions are **relatively short**, indicating that
                sellers often provide minimal information.
                """
            )
            
        st.divider()
        
        st.subheader("Name Length vs Description Length Distribution")
            
        fig = px.histogram(
            df_text,
            x=["name_len", "desc_len"],
            nbins=50,
            opacity=0.6,
            title="Name Length vs Description Length Distribution",
            labels={"value": "Number of Characters", "variable": "Text Field"},
            color_discrete_sequence=["#8B5A2B", "#C19A6B"]
        )

        fig.update_layout(height=700)

        st.plotly_chart(fig, use_container_width=True)

        with st.expander("Insight"):
            st.markdown(
                """
                Product names are consistently shorter, while descriptions show
                higher variability, which is beneficial for text-based modeling.
                """
            )
            
        # Long Desc
        st.divider()
        
        st.subheader("Top 10 Longest Product Descriptions")
        
        top_longest = (
            df_text[df_text["desc_len"] > 0]
            .sort_values("desc_len", ascending=False)
            .head(10)
        )

        fig = px.bar(
            top_longest,
            x="desc_len",
            y="name",
            orientation="h",
            title="Top 10 Longest Product Descriptions",
            labels={"desc_len": "Description Length (chars)", "name": "Product Name"},
            color_discrete_sequence=["#8B5A2B", "#C19A6B"]
        )

        fig.update_layout(
            yaxis=dict(autorange="reversed"),
            height=700
        )

        st.plotly_chart(fig, use_container_width=True)
        
          
        st.divider()
        
        st.subheader("Top 10 Shortest Product Descriptions")
        
        top_shortest = (
            df_text[df_text["desc_len"] > 0]
            .sort_values("desc_len", ascending=True)
            .head(10)
        )

        fig = px.bar(
            top_shortest,
            x="desc_len",
            y="name",
            orientation="h",
            title="Top 10 Shortest Product Descriptions",
            labels={"desc_len": "Description Length (chars)", "name": "Product Name"},
            color_discrete_sequence=["#8B5A2B", "#C19A6B"]
            
        )

        fig.update_layout(
            yaxis=dict(autorange="reversed"),
            height=700
        )

        st.plotly_chart(fig, use_container_width=True)

    # TAB 2
    with tabs[1]:
        df_qc = df_text.copy()

        # Replace 'unknown' with NaN
        df_qc = df_qc.replace("unknown", np.nan)

        # Parameter columns
        param_cols = ["origin", "process", "roast_level", "notes"]

        # Presence indicators
        for col in param_cols:
            df_qc[f"has_{col}"] = df_qc[col].notna().astype(int)

        # Coverage count
        has_cols = [f"has_{c}" for c in param_cols]
        df_qc["coverage_count"] = df_qc[has_cols].sum(axis=1)

        # Coverage level
        def coverage_level(n):
            if n == 0:
                return "no coverage"
            if n == 1:
                return "very low coverage"
            if n == 2:
                return "low coverage"
            if n == 3:
                return "medium coverage"
            return "full coverage"

        df_qc["coverage"] = df_qc["coverage_count"].apply(coverage_level)

        # Text length category
        df_qc["len_cat"] = np.where(df_qc["desc_len"] >= 900, "long", "short")

        # Text quality logic
        def text_quality(row):
            cov = row["coverage"]
            length = row["len_cat"]

            if cov == "full coverage":
                return "excellent" if length == "short" else "very good"
            if cov == "medium coverage":
                return "good"
            if cov == "low coverage":
                return "average"
            if cov == "very low coverage":
                return "very bad" if length == "long" else "average"
            if cov == "no coverage":
                return "very poor" if length == "long" else "poor"

        df_qc["text_quality"] = df_qc.apply(text_quality, axis=1)
        
        
        st.subheader("Quality and Coverage")

        st.markdown(
            """
            This section evaluates the **informativeness of product descriptions**
            using two complementary perspectives:

            - **Coverage**: presence of key coffee attributes (*origin, process, roast level, notes*)
            - **Quality**: relationship between information completeness and text length
            """
        )
        
        st.divider()
        
        col1, col2, col3 = st.columns(3)

        col1.metric(
            "Full Coverage (%)",
            f"{(df_qc['coverage'] == 'full coverage').mean() * 100:.1f}%"
        )

        col2.metric(
            "Good / Very Good Quality (%)",
            f"{df_qc['text_quality'].isin(['good','very good','excellent']).mean() * 100:.1f}%"
        )

        col3.metric(
            "No Coverage (%)",
            f"{(df_qc['coverage'] == 'no coverage').mean() * 100:.2f}%"
        )
        
        with st.expander("Insight"):
            st.markdown(
                """
                Approximately 47.7% of product descriptions achieve full coverage, indicating that over one-third of the dataset contains all key coffee attributes, including origin, processing method, roast level, and flavor notes. 
                In terms of textual quality, 90.9% of descriptions are classified as good to very good, demonstrating that the majority of texts are sufficiently informative relative to their length. 
                Meanwhile, descriptions with no coverage account for only 0.65% of the data, confirming that completely uninformative product descriptions are extremely rare.
                """
            )
        
        st.divider()
        
        # Cov Dis Data 
        coverage_count = df_qc["coverage"].value_counts().reset_index()
        coverage_count.columns = ["coverage", "count"]

        st.subheader("Coverage Distribution of Product Descriptions")
        
        fig = px.bar(
            coverage_count,
            x="coverage",
            y="count",
            labels={"coverage": "Coverage Level", "count": "Number of Products"},
            color_discrete_sequence=["#8B5A2B", "#C19A6B"]
        )

        fig.update_layout(
            height=700,
            xaxis_tickangle=30
        )

        st.plotly_chart(fig, use_container_width=True)
        
        with st.expander("Insight"):
            st.markdown(
                """
                The distribution shows that most product descriptions fall under the medium coverage category, 
                indicating that while several key coffee attributes are commonly included, 
                not all essential information such as origin, processing method, roast level, 
                and flavor notes is consistently provided. This suggests that product descriptions generally contain a moderate level of informativeness, 
                leaving room for improvement in terms of completeness.
                """
            )
            
        st.divider()

        quality_count = df_qc["text_quality"].value_counts().reset_index()
        quality_count.columns = ["text_quality", "count"]
        
        st.subheader("Text Quality Distribution")

        fig = px.bar(
            quality_count,
            x="text_quality",
            y="count",
            labels={"text_quality": "Text Quality", "count": "Number of Products"},
            color_discrete_sequence=["#8B5A2B", "#C19A6B"]
        )

        fig.update_layout(
            height=700,
            xaxis_tickangle=30
        )

        st.plotly_chart(fig, use_container_width=True)
        
        with st.expander("Insight"):
            st.markdown(
                """
                    The majority of products are classified with good or higher text quality,
                    reflecting a positive balance between information completeness and
                    description length. Only a very small number of products are labeled
                    as poor or very bad, indicating that low-quality textual content is
                    not a significant issue within the dataset.
                """
            )

        
    # TAB 3    
    with tabs[2]:
        TEXT_QUALITY_SCORE = {
            "excellent": 5,
            "very good": 4,
            "good": 3,
            "average": 2,
            "poor": 1,
            "very poor": 0,
            "very bad": 0
        }

        df_roastery = df_qc.copy()
        df_roastery["text_quality_score"] = df_roastery["text_quality"].map(TEXT_QUALITY_SCORE)
        
        st.subheader("Roastery Information")

        st.markdown(
            """
            This section analyzes **text informativeness at the roastery level**,
            aiming to identify which roasteries provide the **most complete and
            high-quality product descriptions**.
            """
        )
        
        
        st.subheader("Ranking Roasteries by Average Text Quality")
        roastery_quality = (
            df_roastery
            .groupby("source", as_index=False)
            .agg(
                avg_text_quality=("text_quality_score", "mean"),
                total_products=("text_quality_score", "count")
            )
            .sort_values("avg_text_quality", ascending=False)
        )

        fig = px.bar(
            roastery_quality,
            x="source",
            y="avg_text_quality",
            # title="Ranking Roasteries by Average Text Quality",
            color_discrete_sequence=["#8B5A2B", "#C19A6B"],
            labels={
                "source": "Roastery",
                "avg_text_quality": "Average Text Quality Score"
            },
        )

        fig.update_layout(
            height=700,
            xaxis_tickangle=30
        )

        st.plotly_chart(fig, use_container_width=True)
        with st.expander("Insight"):
            st.markdown(
                """
                The chart indicates notable differences in text quality across roasteries.
                **Protacaba Coffee** ranks highest in average text quality, suggesting that
                its product descriptions are consistently concise yet highly informative.
                In contrast, **Nyawang Langit Roastery** exhibits the lowest average text
                quality, indicating comparatively less detailed or less structured descriptions.
                """
            )
        st.divider()
        
        
        st.subheader("Ranking Roasteries by Average Text Coverage")
        roastery_coverage = (
            df_roastery
            .groupby("source", as_index=False)
            .agg(
                avg_text_coverage=("coverage_count", "mean"),
                total_products=("coverage_count", "count")
            )
            .sort_values("avg_text_coverage", ascending=False)
        )

        fig = px.bar(
            roastery_coverage,
            x="source",
            y="avg_text_coverage",
            color_discrete_sequence=["#8B5A2B", "#C19A6B"],
            labels={
                "source": "Roastery",
                "avg_text_coverage": "Average Coverage Score"
            },
        )

        fig.update_layout(
            height=700,
            xaxis_tickangle=30
        )

        st.plotly_chart(fig, use_container_width=True)
        
        with st.expander("Insight"):
            st.markdown(
                """
                **Sakha Coffee Bali** achieves the highest average text coverage,
                indicating that its product descriptions consistently include
                key attributes such as origin, processing method, roast level,
                and flavor notes. Meanwhile, **Nyawang Langit Roastery** records
                the lowest coverage score, suggesting gaps in the completeness
                of its product descriptions.
                """
            )
        st.divider()
        st.subheader("SUMARY")

        st.markdown(
            """
                The roastery-level analysis reveals systematic differences in
            how product information is presented. **Sakha Coffee Bali** stands
            out in terms of information completeness, while **Protacaba Coffee**
            excels in delivering high-quality descriptions despite relatively
            concise text.

            These findings suggest a potential **informativeness bias** toward
            certain roasteries, which should be considered during the development
            of coffee recommendation models to avoid favoring roasteries with
            inherently richer textual data.
            """
        )
    # TAB 4    
    with tabs[3]:
        st.subheader("Notes, Origin, Process, and Roast Level")

        st.markdown(
            """
            This section explores the most frequently occurring values for **Origin**,
            **Processing Method**, **Flavor Notes**, and **Roast Level**.
            The analysis aims to assess how informative the extracted parameters are,
            while also serving as a secondary validation step to identify potential
            extraction limitations or missing values.
            """
        )
        
        st.subheader("Top 15 Origins by Frequency")
        top_n = 15

        origin_freq = (
            df_qc[df_qc["origin"].notna()]
            .value_counts("origin")
            .reset_index()
            .rename(columns={"count": "frequency"})
            .head(top_n)
        )

        fig = px.bar(
            origin_freq,
            x="origin",
            y="frequency",
            color_discrete_sequence=["#8B5A2B", "#C19A6B"],
            labels={"origin": "Origin", "frequency": "Number of Products"},
        )

        fig.update_layout(
            height=700,
            xaxis_tickangle=30
        )

        st.plotly_chart(fig, use_container_width=True)

        with st.expander("Insight"):
            st.markdown(
                """
                The distribution shows that product origins are concentrated within a
                limited number of regions, with several origins appearing far more
                frequently than others. This indicates that the dataset has a strong
                regional representation, which may reflect market demand or sourcing
                preferences. Less frequent origins may still carry high uniqueness
                but are underrepresented in the dataset.
                """
            )
        st.divider()
        
        
        st.subheader("Top 15 Processing Methods by Frequency")
        process_freq = (
            df_qc[df_qc["process"].notna()]
            .value_counts("process")
            .reset_index()
            .rename(columns={"count": "frequency"})
            .head(top_n)
        )

        fig = px.bar(
            process_freq,
            x="process",
            y="frequency",
            color_discrete_sequence=["#8B5A2B", "#C19A6B"],
            labels={"process": "Process", "frequency": "Number of Products"},
        )

        fig.update_layout(
            height=700,
            xaxis_tickangle=30
        )

        st.plotly_chart(fig, use_container_width=True)
        
        with st.expander("Insight"):
            st.markdown(
                """
                The results reveal a clear dominance of several processing methods,
                such as washed and natural processes. This suggests that the dataset
                is largely composed of commonly used coffee processing techniques,
                while experimental or less conventional processes appear less often.
                """
            )        
        st.divider()
        
        
        st.subheader("Top 15 Flavor Notes by Frequency")
        notes_freq = (
            df_qc[df_qc["notes"].notna()]
            .value_counts("notes")
            .reset_index()
            .rename(columns={"count": "frequency"})
            .head(top_n)
        )

        fig = px.bar(
            notes_freq,
            x="notes",
            y="frequency",
            color_discrete_sequence=["#8B5A2B", "#C19A6B"],
            labels={"notes": "Flavor Notes", "frequency": "Number of Products"},
        )

        fig.update_layout(
            height=700,
            xaxis_tickangle=35
        )

        st.plotly_chart(fig, use_container_width=True)
        
        with st.expander("Insight"):
            st.markdown(
                """
                Flavor notes tend to cluster around familiar sensory descriptors,
                such as chocolate, fruity, and nutty profiles. This suggests that
                roasteries often emphasize broadly recognizable flavors, potentially
                to align with consumer preferences and improve interpretability.
                """
            )
        st.divider()
        
        
        
        st.subheader("Roast Level Distribution")
        roast_level_freq = (
            df_qc[df_qc["roast_level"].notna()]
            .value_counts("roast_level")
            .reset_index()
            .rename(columns={"count": "frequency"})
        )

        fig = px.bar(
            roast_level_freq,
            x="roast_level",
            y="frequency",
            color_discrete_sequence=["#8B5A2B", "#C19A6B"],
            labels={"roast_level": "Roast Level", "frequency": "Number of Products"},
        )

        fig.update_layout(
            height=700
        )

        st.plotly_chart(fig, use_container_width=True)
        
        with st.expander("Insight"):
            st.markdown(
                """
                The distribution indicates a strong preference toward light to medium
                roast levels. This aligns with specialty coffee trends, where lighter
                roasts are often used to highlight origin characteristics and flavor
                complexity, while darker roasts are comparatively less prevalent.
                """
            )
        st.divider()    
                   
        st.subheader("SUMARY")
        
        st.markdown(
            """
            Overall, the extracted parameters demonstrate a high level of
            interpretability, with dominant patterns observed across origin,
            processing method, flavor notes, and roast level. The presence of
            well-defined distributions suggests that the extraction process
            successfully captures meaningful product attributes. However, the
            long-tail distributions also indicate potential opportunities to
            improve extraction coverage for less common or more nuanced attributes.
            """
        )

        # Define Fungsi 100G
    def prepare_products(df):
        df = df.copy()

        # Remove drip bag
        df = df[
            ~df.astype(str)
            .apply(lambda row: row.str.contains("drip bag", case=False).any(), axis=1)
        ]

        df["quantity"] = np.nan

        quantity_patterns = {
            100: r"\b100\s*(g|gr|gram)(?!\s*%)\b",
            150: r"\b150\s*(g|gr|gram)\b",
            200: r"\b200\s*(g|gr|gram)\b",
            400: r"\b400\s*(g|gr|gram)\b",
            500: r"\b500\s*(g|gr|gram)\b",
            1000: r"\b(1000\s*(g|gr|gram)|1\s*kg)\b"
        }

        for qty, pattern in quantity_patterns.items():
            mask = (
                df["quantity"].isna() &
                df[["name", "description"]]
                .astype(str)
                .apply(lambda r: r.str.contains(pattern, case=False, regex=True).any(), axis=1)
            )
            df.loc[mask, "quantity"] = qty

        def extract_gram(row):
            text = f"{row.get('name','')} {row.get('description','')}".lower()

            if re.search(r"\b(l|liter|ml|milliliter|sachet)\b", text):
                return np.nan

            match = re.search(r"\b(\d+)\s*(kg|g|gr|gram)\b", text)
            if not match:
                return np.nan

            value = int(match.group(1))
            unit = match.group(2)

            return value * 1000 if unit == "kg" else value

        mask_null = df["quantity"].isna()
        df.loc[mask_null, "quantity"] = df.loc[mask_null].apply(extract_gram, axis=1)

        df = df.dropna(subset=["quantity"])
        df["price_100g"] = (df["price"] / df["quantity"] * 100).round(0)

        return df

    arabica_product = prepare_products(df_arabica)
    robusta_product = prepare_products(df_robusta)
    
    # TAB 5
    with tabs[4]:

        # -Distrubusi Data
        st.subheader("Coffee Bean Distribution")

        fig = px.pie(
            names=["Robusta", "Arabica"],
            values=[len(df_robusta), len(df_arabica)],
            hole=0.45,
            color_discrete_sequence=["#6F4E37", "#C7A17A"]
        )

        st.plotly_chart(fig, use_container_width=True)

        with st.expander("Insight"):
            st.markdown(
                """
                Arabica products dominate the marketplace, suggesting
                higher consumer demand and broader availability.
                """
            )

        st.divider()

        # Perban Rata - Rata Harga 
        st.subheader("Average Price Comparison")

        avg_price = {
            "Robusta": df_robusta["price"].mean(),
            "Arabica": df_arabica["price"].mean()
        }

        fig = px.bar(
            x=list(avg_price.keys()),
            y=list(avg_price.values()),
            labels={"x": "Coffee Type", "y": "Average Price"},
            color=list(avg_price.keys()),
            color_discrete_sequence=["#8B5A2B", "#C19A6B"]
        )

        st.plotly_chart(fig, use_container_width=True)

        with st.expander("Insight"):
            st.markdown(
                """
                Arabica beans show higher average prices,
                reflecting perceived quality and specialty positioning.
                """
            )

        st.divider()
        
        
        # ARABICA
        st.subheader("Arabica Beans Price Analysis (per 100g)")

        # Termahal
        st.markdown("#### Top 5 Most Expensive Arabica Beans")

        top5_arabica = arabica_product.sort_values(
            "price_100g", ascending=False
        ).head(5)

        fig = px.bar(
            top5_arabica,
            x="price_100g",
            y="name",
            orientation="h",
            labels={"price_100g": "Price per 100g", "name": "Product"},
            color="price_100g",
            color_continuous_scale="YlOrBr"
        )

        fig.update_layout(
            yaxis=dict(autorange="reversed"),
            height=700
        )

        st.plotly_chart(fig, use_container_width=True)

        with st.expander("Insight"):
            st.markdown(
                """
                The most expensive Arabica beans are typically specialty products,
                influenced by origin, processing method, and brand positioning.
                """
            )

        st.divider()

        # Termurah
        st.markdown("#### Top 5 Cheapest Arabica Beans")

        low5_arabica = arabica_product.sort_values(
            "price_100g", ascending=True
        ).head(5)

        fig = px.bar(
            low5_arabica,
            x="price_100g",
            y="name",
            orientation="h",
            labels={"price_100g": "Price per 100g", "name": "Product"},
            color="price_100g",
            color_continuous_scale="YlOrBr"
        )

        fig.update_layout(
            yaxis=dict(autorange="reversed"),
            height=700
        )

        st.plotly_chart(fig, use_container_width=True)

        with st.expander("Insight"):
            st.markdown(
                """
                Cheaper Arabica beans are usually mass-market products
                with larger packaging sizes and minimal branding.
                """
            )

        st.divider()


        # ROBUSTA
        st.subheader("Robusta Beans Price Analysis (per 100g)")

        # Robusta Termahal
        st.markdown("#### Top 5 Most Expensive Robusta Beans")

        top5_robusta = robusta_product.sort_values(
            "price_100g", ascending=False
        ).head(5)

        fig = px.bar(
            top5_robusta,
            x="price_100g",
            y="name",
            orientation="h",
            labels={"price_100g": "Price per 100g", "name": "Product"},
            color="price_100g",
            color_continuous_scale="YlOrBr"
        )

        fig.update_layout(
            yaxis=dict(autorange="reversed"),
            height=700
        )

        st.plotly_chart(fig, use_container_width=True)

        with st.expander("Insight"):
            st.markdown(
                """
                Premium Robusta products usually target espresso blends
                or users seeking high caffeine content.
                """
            )

        st.divider()

        # Robusta Termurah
        st.markdown("#### Top 5 Cheapest Robusta Beans")

        low5_robusta = robusta_product.sort_values(
            "price_100g", ascending=True
        ).head(5)

        fig = px.bar(
            low5_robusta,
            x="price_100g",
            y="name",
            orientation="h",
            labels={"price_100g": "Price per 100g", "name": "Product"},
            color="price_100g",
            color_continuous_scale="YlOrBr"
        )

        fig.update_layout(
            yaxis=dict(autorange="reversed"),
            height=700
        )

        st.plotly_chart(fig, use_container_width=True)

        with st.expander("Insight"):
            st.markdown(
                """
                Low-priced Robusta beans are often sold in bulk
                and commonly used for daily consumption.
                """
            )

# PREDICT
elif choice == "Predict":
    run_predict()
